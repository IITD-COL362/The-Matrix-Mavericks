Sample user name : Vis1
Sample password : hehe1234


##Instructions to run the web application
->Download our submission
->Make all the installations and set up provided using "bash setup_front_end.sh"
->After that run the web application using "bash run.sh"
->Click on the link coming on the terminal and then use the portal using above details