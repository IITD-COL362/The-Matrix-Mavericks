Sample user name : Vis1
Sample password : hehe1234


##Instructions to run the web application
->Download our submission
->Make all the installations and set up provided using "source setup_front_end.sh" or ". setup_front_end.sh"
->Note that "setup_front_end.sh" can't be run using "bash" command because we make installations in an environment but
	bash opens up a new terminal and is not able to activate the environment.
->After that run the web application using "bash run.sh"
->Click on the link coming on the terminal and then use the portal using above details
