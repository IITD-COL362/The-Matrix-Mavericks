from django.shortcuts import render
from django.db import connection
from django.utils import timezone, dateformat
from .forms import MealCountForm, AddMealForm , UpdateWeightForm, UpdateAddressForm, UpdateCityForm, UpdateMailidForm, UpdatePhonenumberForm
import datetime

def city_list(request):
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM City")
        cities = cursor.fetchall()

    return render(request, 'city_list.html', {'cities': cities})

def meal_count(request):
    if request.method == 'POST':
        form = MealCountForm(request.POST)
        if form.is_valid():
            person_id = form.cleaned_data['person_id']
            with connection.cursor() as cursor:
                cursor.execute(f"SELECT COUNT(*) FROM Meal WHERE Person_id={person_id}")
                meal_count = cursor.fetchone()[0]
            return render(request, 'meal_count_result.html', {'meal_count': meal_count})
    else:
        form = MealCountForm()
    return render(request, 'meal_count.html', {'form': form})


def dashboard(request):
    enddate = dateformat.format(timezone.now().date(),'\'Y-m-d\'')
    startdate = dateformat.format(timezone.now() - datetime.timedelta(days=7),'\'Y-m-d\'')
    personid = request.user 
    with connection.cursor() as cursor:
        cursor.execute(f"select count(*) from meal where person_id = '{personid}' and entry_type = 'Track' and meal_date >= {startdate} and meal_date <= {enddate};")
        tracked_meals = cursor.fetchone()[0]
    with connection.cursor() as cursor:
        cursor.execute(f"with t as (select * from meal where person_id = '{personid}' and meal_date >= {startdate} and meal_date <= {enddate}) select sum(meal_type_score) as total_score from t,meal_type_details where t.meal_type_id = meal_type_details.meal_type_id")
        user_score = cursor.fetchone()[0]
    with connection.cursor() as cursor:
        cursor.execute(f"select 1.0*count(*)/7 as avg_meals from meal where person_id = '{personid}' and meal_date >= {startdate} and meal_date <= {enddate}")
        avg_meals = cursor.fetchone()[0]
    context = {
        'tracked_meals': tracked_meals,
        'user_score': user_score,
        'avg_meals': avg_meals,
    }
    return render(request, 'dashboard.html', context)

                
def add_meal(request):
    mealtime = timezone.localtime(timezone.now()).strftime('\'%H:%M:%S\'')
    mealdate = dateformat.format(timezone.now().date(),'\'Y-m-d\'')
    if request.method == 'POST':
        form = AddMealForm(request.POST)
        if form.is_valid():
            meal_type = form.cleaned_data['meal_type']
            with connection.cursor() as cursor:
                cursor.execute("SELECT COUNT(*) FROM MEAL")
                curr_max = cursor.fetchone()[0]
            next_max = curr_max+1
            print(next_max)
            with connection.cursor() as cursor:
                cursor.execute(f"INSERT INTO MEAL VALUES ({next_max},'{meal_type}','{request.user}',{mealtime},{mealdate},'Self',NULL,NULL)")
            return render(request, 'meal_count_result.html', {'meal_count': meal_count})
    else:
        form = AddMealForm()
    return render(request, 'add_meal.html', {'form': form})

def statistics_user(request):
    personid = request.user
    with connection.cursor() as cursor:
        cursor.execute(f"with t as (select meal_type_id as meal_type,0 as number_of_meals from meal_type_details union all select meal_type_id as meal_type,count(*) from meal where person_id = '{personid}' group by meal_type_id),sum_table as (select (case when sum(number_of_meals)<=0 then 1 else sum(number_of_meals) end) as total_meals from t), val_table as (select meal_type,sum(number_of_meals) as count_meals from t group by meal_type) select meal_type,100.0*count_meals/total_meals as percent_of_meals from val_table,sum_table")
        data = cursor.fetchall()
    return render(request,'stats.html',{'data': data })

def profile_user(request):
    personid = request.user
    with connection.cursor() as cursor:
        cursor.execute(f"select * from user_data where user_id = '{personid}'")
        data = cursor.fetchall()
    return render(request,'profile.html',{'data': data})
        
# # update address,city,mailid,phonenumber,weight
def update_weight(request):
	personid = request.user
	if request.method == 'POST':
		form = UpdateWeightForm(request.POST)
		if form.is_valid():
			new_weight = form.cleaned_data['new_weight']
			with connection.cursor() as cursor:
				cursor.execute(f"update user_data set weight = {new_weight} where user_id='{personid}'")
			return render(request,'successful.html',{'form':form})
	else:
		form = UpdateWeightForm()
	return render(request,'update_weight.html',{'form':form})

def update_address(request):
	personid = request.user
	if request.method == 'POST':
		form = UpdateAddressForm(request.POST)
		if form.is_valid():
			new_address = form.cleaned_data['new_address']
			with connection.cursor() as cursor:
				cursor.execute(f"update user_data set address = '{new_address}' where user_id='{personid}'")
			return render(request,'successful.html',{'form':form})
	else:
		form = UpdateAddressForm()
	return render(request,'update_address.html',{'form':form})

def update_city(request):
	personid = request.user
	if request.method == 'POST':
		form = UpdateCityForm(request.POST)
		if form.is_valid():
			new_city = form.cleaned_data['new_city']
			with connection.cursor() as cursor:
				cursor.execute(f"update user_data set city_id = '{new_city}' where user_id='{personid}'")
			return render(request,'successful.html',{'form':form})
	else:
		form = UpdateCityForm()
	return render(request,'update_city.html',{'form':form})

def update_mailid(request):
	personid = request.user
	if request.method == 'POST':
		form = UpdateMailidForm(request.POST)
		if form.is_valid():
			new_mailid = form.cleaned_data['new_mailid']
			with connection.cursor() as cursor:
				cursor.execute(f"update user_data set mailid = '{new_mailid}' where user_id='{personid}'")
			return render(request,'successful.html',{'form':form})
	else:
		form = UpdateMailidForm()
	return render(request,'update_mailid.html',{'form':form})

def update_phonenumber(request):
	personid = request.user
	if request.method == 'POST':
		form = UpdatePhonenumberForm(request.POST)
		if form.is_valid():
			new_phonenumber = form.cleaned_data['new_phonenumber']
			with connection.cursor() as cursor:
				cursor.execute(f"update user_data set phone_number = {new_phonenumber} where user_id='{personid}'")
			return render(request,'successful.html',{'form':form})
	else:
		form = UpdatePhonenumberForm()
	return render(request,'update_phonenumber.html',{'form':form})
    
    
    
    
    
    

        







