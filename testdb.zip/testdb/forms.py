from django import forms

MEAL_CHOICES= [
    ('Fruits', 'Fruits'),
    ('Wheat based', 'Wheat based'),
    ('Rice based', 'Rice based'),
    ('Meat based', 'Meat based'),
    ('Sea food based', 'Sea food based'),
    ('Salad based', 'Salad based'),
    ('Milk based', 'Milk based'),
    ('Junk food', 'Junk food'),
    ('Vegetarian based', 'Vegetarian based'),
    ('Dessert', 'Dessert'),
    ('Egg based', 'Egg based'),
    ]

class MealCountForm(forms.Form):
    person_id = forms.IntegerField(label='Enter Person ID')
    
class AddMealForm(forms.Form):
    meal_type = forms.CharField(label = 'What type of meal did you eat ? ',widget=forms.Select(choices = MEAL_CHOICES))
    
class UpdateWeightForm(forms.Form):
    new_weight = forms.IntegerField(label='Enter the new weight')
    
class UpdateMailidForm(forms.Form):
    new_mailid = forms.CharField(label='Enter the new mail id')
    
class UpdatePhonenumberForm(forms.Form):
    new_phonenumber = forms.IntegerField(label='Enter the new phone number')
    
class UpdateCityForm(forms.Form):
    new_city = forms.CharField(label='Enter the new city')
    
class UpdateAddressForm(forms.Form):
    new_address = forms.CharField(label='Enter the new address')
    
class LocationForm(forms.Form):
    latitude = forms.FloatField(label = 'Enter your latitude' )
    longitude = forms.FloatField(label = 'Enter your longitude') 
