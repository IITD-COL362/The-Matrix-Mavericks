from django.urls import path
from . import views


urlpatterns = [
   path('restaurant/', views.filter_restaurant,name='filter_restaurant'),
   path('food/', views.filter_food,name='filter_food'),
   path('mix/', views.filter_mix,name='filter_mix')
]
