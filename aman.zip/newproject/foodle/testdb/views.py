# Create your views here.

from django.shortcuts import render
from django.db import connection
from .forms import RestForm,FoodForm,MixForm

is_name=True
is_city=True
is_avgcost=True
is_htb=True
is_hod=True
is_idn=True
is_stom=True
is_rating=True
is_votes=True
fname='Chokhi Dhani'
fcity='Jaipur'
favgcost1=0
favgcost2=100
fhtb='YES'
fhod='YES'
fidn='YES'
fstom='YES'
frating=1
fvotes=100
fcountry='India'



is_cuisine=True
is_calorie=True
is_fat=True
is_carbohydrate=True
is_protein=True
is_sodium=True
is_meal=True
is_veg=True
fcuisine='Salad'
fcalorie1=0
fcalorie2=0
ffat1=0
ffat2=0
fcarbohydrate1=0
fcarbohydrate2=0
fprotein1=0
fprotein2=0
fsodium1=0
fsodium2=0
fmeal='Wheat Based'
fveg='V'



def filter_food(request):
    global is_calorie,is_carbohydrate,is_protein,is_fat,is_sodium,is_cuisine,is_meal,is_veg
    global fcalorie1,fcalorie2,ffat1,ffat2,fcarbohydrate1,fcarbohydrate2,fprotein1,fprotein2,fsodium1,fsodium2,fmeal,fveg,fcuisine
    if request.method=='POST' :
        form=FoodForm(request.POST)
        if form.is_valid():
            fcuisine=form.cleaned_data['cuisine']
            fcalorie=form.cleaned_data['calorie']
            ffat=form.cleaned_data['fat']
            fprotein=form.cleaned_data['protein']
            fcarbohydrate=form.cleaned_data['carbohydrate']
            fsodium=form.cleaned_data['sodium']
            fveg=form.cleaned_data['veg']
            fmeal=form.cleaned_data['meal']
            if (fcuisine=='Select') :
                is_cuisine=True
            else :
                is_cuisine=False
            if fmeal=='Select' :
                is_meal=True
            else :
                is_meal=False
            if (fveg=='Select') :
                is_veg=True
            else :
                is_veg=False
            if (fprotein=='Select') :
                is_protein=True
            elif fprotein=='low':
                is_protein=False
                fprotein1=0
                fprotein2=11
            elif fprotein=='medium':
                is_protein=False
                fprotein1=11
                fprotein2=30
            else :
                is_protein=False
                fprotein1=30
                fprotein2=100
            if (fcarbohydrate=='Select') :
                is_carbohydrate=True
            elif fcarbohydrate=='low':
                is_carbohydrate=False
                fcarbohydrate1=0
                fcarbohydrate2=20
            elif fcarbohydrate=='medium':
                is_carbohydrate=False
                fcarbohydrate1=20
                fcarbohydrate2=40
            else :
                is_carbohydrate=False
                fcarbohydrate1=40
                fcarbohydrate2=100
            if (ffat=='Select') :
                is_fat=True
            elif ffat=='low':
                is_fat=False
                ffat1=0
                ffat2=10
            elif ffat=='medium':
                is_fat=False
                ffat1=10
                ffat2=30
            else :
                is_fat=False
                ffat1=30
                ffat2=100
            if (fcalorie=='Select') :
                is_calorie=True
            elif fcalorie=='low':
                is_calorie=False
                fcalorie1=0
                fcalorie2=220
            elif fcalorie=='medium':
                is_calorie=False
                fcalorie1=220
                fcalorie2=440
            else :
                is_calorie=False
                fcalorie1=440
                fcalorie2=10000
            if (fsodium=='Select') :
                is_sodium=True
            elif fsodium=='low':
                is_sodium=False
                fsodium1=0
                fsodium2=395
            elif fsodium=='medium':
                is_sodium=False
                fsodium1=395
                fsodium2=1000
            else :
                is_sodium=False
                fsodium1=1000
                fsodium2=10000
            with connection.cursor() as cursor:
                cursor.execute(f"select * from food where ({is_cuisine} or cuisine_id='{fcuisine}') and ({is_calorie} or (calories>={fcalorie1} and calories<={fcalorie2})) and ({is_fat} or (fat<={ffat2} and fat>={ffat1})) and ({is_carbohydrate} or (carbohydrates>={fcarbohydrate1} and carbohydrates<={fcarbohydrate2})) and ({is_protein} or (protein>={fprotein1} and protein<={fprotein2})) and ({is_sodium} or (sodium>={fsodium1} and sodium<={fsodium2})) and ({is_meal} or meal_type_id='{fmeal}') and ({is_veg} or veg_non_veg='{fveg}') order by food_id asc")
                foods = cursor.fetchall()
            render(request,'food.html',{'form':form,'foods':foods})
    else:
        form = FoodForm()
        foods={}
    return render(request,'food.html',{'form':form,'foods':foods})



def filter_restaurant(request):
    global is_city,is_avgcost,is_hod,is_htb,is_idn,is_stom,is_rating,is_name,is_votes
    global fcity,favgcost1,favgcost2,frating,fvotes,fname,fhtb,fhod,fidn,fstom,fcountry
    global is_calorie,is_carbohydrate,is_protein,is_fat,is_sodium,is_cuisine,is_meal,is_veg
    global fcalorie1,fcalorie2,ffat1,ffat2,fcarbohydrate1,fcarbohydrate2,fprotein1,fprotein2,fsodium1,fsodium2,fmeal,fveg,fcuisine
    if request.method == 'POST':
        form = RestForm(request.POST)
        if form.is_valid():
            fcountry=form.cleaned_data['country']
            fcity = form.cleaned_data['city']
            frating = form.cleaned_data['rating']
            favgcost1 = form.cleaned_data['avgcost1']
            favgcost2 = form.cleaned_data['avgcost2']
            fvotes = form.cleaned_data['votes']
            fhtb = form.cleaned_data['htb']
            fhod = form.cleaned_data['hod']
            fidn = form.cleaned_data['idn']
            fstom = form.cleaned_data['stom']
            if (fcity=='Select') :
                is_city=True
            else :
                is_city=False
            if (frating=='Select') :
                is_rating=True
            else :
                is_rating=False
            if (fvotes=='Select') :
                is_votes=True
            else :
                is_votes=False
            if (favgcost1=='Select') :
                is_avgcost=True
            else :
                is_avgcost=False
            if (fhtb=='Select') :
                is_htb=True
            else :
                is_htb=False
            if (fhod=='Select') :
                is_hod=True
            else :
                is_hod=False
            if (fidn=='Select') :
                is_idn=True
            else :
                is_idn=False
            if (fstom=='Select') :
                is_stom=True
            else :
                is_stom=False
            restaurants={}
            if (fcountry=='Select') :
                with connection.cursor() as cursor:
                    cursor.execute(f"select * from restaurant where ({is_name} or name='{fname}') and ({is_city} or city_id='{fcity}') and ({is_avgcost} or (avg_cost_for_two>={favgcost1} and avg_cost_for_two<{favgcost2})) and ({is_htb} or has_table_booking='{fhtb}') and ({is_hod} or has_online_delivery='{fhod}') and ({is_idn} or is_delivering_now='{fidn}') and ({is_stom} or switch_to_order_menu='{fstom}') and ({is_rating} or aggregate_rating>={frating}) and ({is_votes} or votes>={fvotes}) order by aggregate_rating desc")
                    restaurants = cursor.fetchall()
            else :
                with connection.cursor() as cursor:
                    cursor.execute(f"with var as (select * from restaurant where ({is_name} or name='{fname}') and ({is_city} or city_id='{fcity}') and ({is_avgcost} or (avg_cost_for_two>={favgcost1} and avg_cost_for_two<{favgcost2})) and ({is_htb} or has_table_booking='{fhtb}') and ({is_hod} or has_online_delivery='{fhod}') and ({is_idn} or is_delivering_now='{fidn}') and ({is_stom} or switch_to_order_menu='{fstom}') and ({is_rating} or aggregate_rating>={frating}) and ({is_votes} or votes>={fvotes}) order by aggregate_rating desc),nvar as (select * from var,city where var.city_id=city.city_id and country_name='{fcountry}') select * from nvar order by aggregate_rating desc")
                    restaurants = cursor.fetchall()
            render(request,'home.html',{'form':form,'restaurants':restaurants})
            # Do something with attribute and filter
    else:
        form = RestForm()
        restaurants={}
    return render(request,'home.html',{'form':form,'restaurants':restaurants})





def filter_mix(request) :
    global is_city,is_avgcost,is_hod,is_htb,is_idn,is_stom,is_rating,is_name,is_votes
    global fcity,favgcost1,favgcost2,frating,fvotes,fname,fhtb,fhod,fidn,fstom,fcountry
    global is_calorie,is_carbohydrate,is_protein,is_fat,is_sodium,is_cuisine,is_meal,is_veg
    global fcalorie1,fcalorie2,ffat1,ffat2,fcarbohydrate1,fcarbohydrate2,fprotein1,fprotein2,fsodium1,fsodium2,fmeal,fveg,fcuisine
    if request.method == 'POST':
        form = MixForm(request.POST)
        if form.is_valid() :
            fcountry=form.cleaned_data['country']
            fcity = form.cleaned_data['city']
            frating = form.cleaned_data['rating']
            favgcost1 = form.cleaned_data['avgcost1']
            favgcost2 = form.cleaned_data['avgcost2']
            fvotes = form.cleaned_data['votes']
            fhtb = form.cleaned_data['htb']
            fhod = form.cleaned_data['hod']
            fidn = form.cleaned_data['idn']
            fstom = form.cleaned_data['stom']
            fcuisine=form.cleaned_data['cuisine']
            fcalorie=form.cleaned_data['calorie']
            ffat=form.cleaned_data['fat']
            fprotein=form.cleaned_data['protein']
            fcarbohydrate=form.cleaned_data['carbohydrate']
            fsodium=form.cleaned_data['sodium']
            fveg=form.cleaned_data['veg']
            fmeal=form.cleaned_data['meal']
            if (fcity=='Select') :
                is_city=True
            else :
                is_city=False
            if (frating=='Select') :
                is_rating=True
            else :
                is_rating=False
            if (fvotes=='Select') :
                is_votes=True
            else :
                is_votes=False
            if (favgcost1=='Select') :
                is_avgcost=True
            else :
                is_avgcost=False
            if (fhtb=='Select') :
                is_htb=True
            else :
                is_htb=False
            if (fhod=='Select') :
                is_hod=True
            else :
                is_hod=False
            if (fidn=='Select') :
                is_idn=True
            else :
                is_idn=False
            if (fstom=='Select') :
                is_stom=True
            else :
                is_stom=False
            if (fcuisine=='Select') :
                is_cuisine=True
            else :
                is_cuisine=False
            if fmeal=='Select' :
                is_meal=True
            else :
                is_meal=False
            if (fveg=='Select') :
                is_veg=True
            else :
                is_veg=False
            if (fprotein=='Select') :
                is_protein=True
            elif fprotein=='low':
                is_protein=False
                fprotein1=0
                fprotein2=11
            elif fprotein=='medium':
                is_protein=False
                fprotein1=11
                fprotein2=30
            else :
                is_protein=False
                fprotein1=30
                fprotein2=100
            if (fcarbohydrate=='Select') :
                is_carbohydrate=True
            elif fcarbohydrate=='low':
                is_carbohydrate=False
                fcarbohydrate1=0
                fcarbohydrate2=20
            elif fcarbohydrate=='medium':
                is_carbohydrate=False
                fcarbohydrate1=20
                fcarbohydrate2=40
            else :
                is_carbohydrate=False
                fcarbohydrate1=40
                fcarbohydrate2=100
            if (ffat=='Select') :
                is_fat=True
            elif ffat=='low':
                is_fat=False
                ffat1=0
                ffat2=10
            elif ffat=='medium':
                is_fat=False
                ffat1=10
                ffat2=30
            else :
                is_fat=False
                ffat1=30
                ffat2=100
            if (fcalorie=='Select') :
                is_calorie=True
            elif fcalorie=='low':
                is_calorie=False
                fcalorie1=0
                fcalorie2=220
            elif fcalorie=='medium':
                is_calorie=False
                fcalorie1=220
                fcalorie2=440
            else :
                is_calorie=False
                fcalorie1=440
                fcalorie2=10000
            if (fsodium=='Select') :
                is_sodium=True
            elif fsodium=='low':
                is_sodium=False
                fsodium1=0
                fsodium2=395
            elif fsodium=='medium':
                is_sodium=False
                fsodium1=395
                fsodium2=1000
            else :
                is_sodium=False
                fsodium1=1000
                fsodium2=10000
            restaurants={}
            if (fcountry=='Select') :
                with connection.cursor() as cursor:
                    cursor.execute(f"with var as (select * from food where ({is_cuisine} or cuisine_id='{fcuisine}') and ({is_calorie} or (calories>={fcalorie1} and calories<={fcalorie2})) and ({is_fat} or (fat<={ffat2} and fat>={ffat1})) and ({is_carbohydrate} or (carbohydrates>={fcarbohydrate1} and carbohydrates<={fcarbohydrate2})) and ({is_protein} or (protein>={fprotein1} and protein<={fprotein2})) and ({is_sodium} or (sodium>={fsodium1} and sodium<={fsodium2})) and ({is_meal} or meal_type_id='{fmeal}') and ({is_veg} or veg_non_veg='{fveg}') order by food_id asc),nvar as (select cuisine_id,count(*) as noi from var group by cuisine_id),fvar as (select restaurant_id,sum(noi) as tnoi from restaurant_cuisine,nvar where restaurant_cuisine.cuisine_id=nvar.cuisine_id group by restaurant_id),tvar as (select * from (select * from restaurant,fvar where restaurant.restaurant_id=fvar.restaurant_id) as tab where ({is_name} or name='{fname}') and ({is_city} or city_id='{fcity}') and ({is_avgcost} or (avg_cost_for_two>={favgcost1} and avg_cost_for_two<{favgcost2})) and ({is_htb} or has_table_booking='{fhtb}') and ({is_hod} or has_online_delivery='{fhod}') and ({is_idn} or is_delivering_now='{fidn}') and ({is_stom} or switch_to_order_menu='{fstom}') and ({is_rating} or aggregate_rating>={frating}) and ({is_votes} or votes>={fvotes}) order by aggregate_rating desc) select * from tvar order by tnoi desc,name asc")
                    restaurants = cursor.fetchall()
            else :
                with connection.cursor() as cursor:
                    cursor.execute(f"with var as (select * from food where ({is_cuisine} or cuisine_id='{fcuisine}') and ({is_calorie} or (calories>={fcalorie1} and calories<={fcalorie2})) and ({is_fat} or (fat<={ffat2} and fat>={ffat1})) and ({is_carbohydrate} or (carbohydrates>={fcarbohydrate1} and carbohydrates<={fcarbohydrate2})) and ({is_protein} or (protein>={fprotein1} and protein<={fprotein2})) and ({is_sodium} or (sodium>={fsodium1} and sodium<={fsodium2})) and ({is_meal} or meal_type_id='{fmeal}') and ({is_veg} or veg_non_veg='{fveg}') order by food_id asc),nvar as (select cuisine_id,count(*) as noi from var group by cuisine_id),fvar as (select restaurant_id,sum(noi) as tnoi from restaurant_cuisine,nvar where restaurant_cuisine.cuisine_id=nvar.cuisine_id group by restaurant_id),tvar as (select * from (select * from restaurant,fvar where restaurant.restaurant_id=fvar.restaurant_id) as tab where ({is_name} or name='{fname}') and ({is_city} or city_id='{fcity}') and ({is_avgcost} or (avg_cost_for_two>={favgcost1} and avg_cost_for_two<{favgcost2})) and ({is_htb} or has_table_booking='{fhtb}') and ({is_hod} or has_online_delivery='{fhod}') and ({is_idn} or is_delivering_now='{fidn}') and ({is_stom} or switch_to_order_menu='{fstom}') and ({is_rating} or aggregate_rating>={frating}) and ({is_votes} or votes>={fvotes}) order by aggregate_rating desc) select * from tvar order by tnoi desc,name asc")
                    restaurants = cursor.fetchall()
            render(request,'mix.html',{'form':form,'restaurants':restaurants})
            # Do something with attribute and filter
    else:
        form = MixForm()
        restaurants={}
    return render(request,'mix.html',{'form':form,'restaurants':restaurants})