python3 -m venv my_env
. my_env/bin/activate
pip install django
pip install psycopg2-binary
