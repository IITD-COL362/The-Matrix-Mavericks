from django.shortcuts import render
from django.db import connection
from .forms import MealCountForm
from django.utils import timezone, dateformat

def city_list(request):
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM City")
        cities = cursor.fetchall()

    return render(request, 'city_list.html', {'cities': cities})

def meal_count(request):
    if request.method == 'POST':
        form = MealCountForm(request.POST)
        if form.is_valid():
            person_id = form.cleaned_data['person_id']
            with connection.cursor() as cursor:
                cursor.execute(f"SELECT COUNT(*) FROM Meal WHERE Person_id={person_id}")
                meal_count = cursor.fetchone()[0]
            return render(request, 'meal_count_result.html', {'meal_count': meal_count})
    else:
        form = MealCountForm()
    return render(request, 'meal_count.html', {'form': form})

def trending(request):
    # meal_date = dateformat.format(timezone.now().date(),'\'Y-m-d\'')
    meal_date = '\'2022-03-13\''
    with connection.cursor() as cursor:
        cursor.execute(f"select restaurant.restaurant_id, restaurant.name, noo from (select restaurant_id,count(*) as noo from meal where meal.entry_type='Track' and meal.meal_date >= {meal_date} group by restaurant_id order by noo desc limit 5) as t, restaurant where restaurant.restaurant_id = t.restaurant_id")
        top5a = cursor.fetchall()
    with connection.cursor() as cursor:
        cursor.execute(f"select food.food_id, food_name, noo from (select food_id,count(*) as noo from meal where meal.entry_type='Track' and meal.meal_date >= {meal_date} group by food_id order by noo desc limit 5) as t, food where food.food_id = t.food_id")
        top5b = cursor.fetchall()
    with connection.cursor() as cursor:
        cursor.execute(f"select meal_type_id,count(*) as noo from meal where meal.entry_type='Track' and meal.meal_date >= {meal_date} group by meal_type_id order by noo desc limit 5")
        top5c = cursor.fetchall()
    with connection.cursor() as cursor:
        cursor.execute(f"with var as (select food_id,count(*) as noo from meal where meal.entry_type='Track' and meal.meal_date >= {meal_date} group by food_id), nvar as (select cuisine_id,count(*) as noc from food,var where food.food_id=var.food_id group by cuisine_id order by noc desc limit 5) select * from nvar")
        top5d = cursor.fetchall()      
    return render(request, 'trending.html', {'top5a': top5a,'top5b': top5b,'top5c': top5c,'top5d': top5d})

def restaurant_detail(request, restaurant_id):
    with connection.cursor() as cursor:
        cursor.execute(f"select * from restaurant where restaurant_id='{restaurant_id}'")
        restaurant = cursor.fetchall()
    return render(request, 'restaurant_detail.html', {'restaurant': restaurant})

def menu(request, restaurant_id, SwitchMenu):
    # if(SwitchMenu=="No"):
    #     return render(request, 'sorry.html')
    # else:
    with connection.cursor() as cursor:
        cursor.execute(f"select food.* from food, restaurant_cuisine where restaurant_id='{restaurant_id}' and food.cuisine_id=restaurant_cuisine.cuisine_id")
        menu = cursor.fetchall()
    return render(request, 'menu.html', {'menu': menu})
