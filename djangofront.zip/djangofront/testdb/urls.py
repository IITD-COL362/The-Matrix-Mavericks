from django.urls import path
from . import views
from django.views.generic.base import TemplateView

urlpatterns = [
    path('city-list/', views.city_list, name='city_list'),
    path('meal-count/', views.meal_count, name='meal_count'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('dashboard/add_meal/', views.add_meal, name='add_meal'),
    path('dashboard/stats/',views.statistics_user, name = 'statistics_user'),
	path('', TemplateView.as_view(template_name='home.html'), name='home'),
]
