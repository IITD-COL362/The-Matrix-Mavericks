from django.urls import path
from . import views
from django.views.generic.base import TemplateView

urlpatterns = [
    path('city-list/', views.city_list, name='city_list'),
    path('meal-count/', views.meal_count, name='meal_count'),
	path('', TemplateView.as_view(template_name='home.html'), name='home'),
]
