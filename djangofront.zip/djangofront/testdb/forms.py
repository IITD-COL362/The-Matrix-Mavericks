from django import forms

MEAL_CHOICES= [
    ('Fruits', 'Fruits'),
    ('Wheat based', 'Wheat based'),
    ('Rice based', 'Rice based'),
    ('Meat based', 'Meat based'),
    ('Sea food based', 'Sea food based'),
    ('Salad based', 'Salad based'),
    ('Milk based', 'Milk based'),
    ('Junk food', 'Junk food'),
    ('Vegetarian based', 'Vegetarian based'),
    ('Dessert', 'Dessert'),
    ('Egg based', 'Egg based'),
    ]

class MealCountForm(forms.Form):
    person_id = forms.IntegerField(label='Enter Person ID')
    
class AddMealForm(forms.Form):
    meal_type = forms.CharField(label = 'What type of meal did you eat ? ',widget=forms.Select(choices = MEAL_CHOICES))
