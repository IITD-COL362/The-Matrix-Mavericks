from django import forms

class MealCountForm(forms.Form):
    person_id = forms.IntegerField(label='Enter Person ID')
