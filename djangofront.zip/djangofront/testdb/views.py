from django.shortcuts import render
from django.db import connection
from .forms import MealCountForm

def city_list(request):
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM City")
        cities = cursor.fetchall()

    return render(request, 'city_list.html', {'cities': cities})

# def meal_count(request):
#     if request.method == 'POST':
#         person_id = request.POST.get('person_id')
#         with connection.cursor() as cursor:
#             cursor.execute("SELECT COUNT(*) FROM meals WHERE Person_id = %s", [person_id])
#             meal_count = cursor.fetchone()[0]
#         return render(request, 'meal_count.html', {'meal_count': meal_count})
#     else:
#         return render(request, 'meal_input.html')

def meal_count(request):
    if request.method == 'POST':
        form = MealCountForm(request.POST)
        if form.is_valid():
            person_id = form.cleaned_data['person_id']
            with connection.cursor() as cursor:
                cursor.execute(f"SELECT COUNT(*) FROM Meal WHERE Person_id={person_id}")
                meal_count = cursor.fetchone()[0]
            return render(request, 'meal_count_result.html', {'meal_count': meal_count})
    else:
        form = MealCountForm()
    return render(request, 'meal_count.html', {'form': form})
